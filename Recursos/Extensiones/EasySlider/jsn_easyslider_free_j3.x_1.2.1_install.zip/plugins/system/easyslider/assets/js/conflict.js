var JSNES_Underscore = _;
var JSNES_jQuery = jQuery.noConflict();
var JSNES_Backbone = Backbone.noConflict();