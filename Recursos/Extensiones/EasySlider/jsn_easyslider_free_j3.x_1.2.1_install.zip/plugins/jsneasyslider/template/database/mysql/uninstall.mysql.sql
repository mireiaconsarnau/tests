DROP TABLE IF EXISTS `#__jsn_easyslider_item_templates`;
DROP TABLE IF EXISTS `#__jsn_easyslider_slide_templates`;
